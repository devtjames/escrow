/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*.html", "./student/**/*.html", "./admin/**/*.html", "./assets/js/**/*.js"],
  darkMode: "class"
};
